package service;

import com.google.gson.Gson;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ApiCliente {
    private static  final String URL = "https://mocki.io/v1/eeced007-6b29-4c9d-ab63-c115a990d927/";
    private static Retrofit retrofit = null;

    public static Retrofit retrofitt(){
    if (retrofit==null){
    retrofit = new Retrofit.Builder().baseUrl(URL).addConverterFactory(GsonConverterFactory.create()).build();

    }
    return retrofit;
    }
}
