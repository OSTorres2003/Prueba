package service;

import com.example.myapplication.models.Donut;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface ApiService {
    @GET("https://mocki.io/v1/eeced007-6b29-4c9d-ab63-c115a990d927")
    Call<List<Donut>> getDonut();

}
