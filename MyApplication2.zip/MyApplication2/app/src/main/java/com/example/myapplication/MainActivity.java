package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;

import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {

    Pattern pattern = Pattern.compile(".[A-Z].");
    EditText txtUsernameField;
    EditText txtPasswordField;
    Button btnLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.txtUsernameField = findViewById(R.id.txtUsernameField);
        this.txtPasswordField = findViewById(R.id.txtPasswordField);
        this.btnLogin = findViewById(R.id.btnLogin);
        this.btnLogin.setOnClickListener(view -> {
            if(this.txtUsernameField.getText().toString().length() < 8){
                Toast.makeText(MainActivity.this, "El usario debe contener al menos 8 carácteres", Toast.LENGTH_LONG).show();
            } else if (this.txtPasswordField.getText().toString().length() < 6) {
                Toast.makeText(MainActivity.this, "La contraseña debe contener al menos 6 carácteres", Toast.LENGTH_LONG).show();
            } else if (pattern.matcher(this.txtPasswordField.getText().toString()).matches()) {
                Toast.makeText(MainActivity.this, "La contraseña debe contener al menos una mayuscula", Toast.LENGTH_LONG).show();
            } else{
              //savesession(this.txtUsernameField.getText().toString(),this.txtPasswordField.getText().toString());
               startActivity(new Intent(MainActivity.this, Home.class));
            }
        });
    }

    private void navigation(){}
    private boolean hasSession(){
        return false;
    }
    public void  savesession (String buttonNumber, String password) {
        SharedPreferences sharedPref = getSharedPreferences("application", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putString("Password",password);
        editor.putString("Username", buttonNumber);
        editor.apply();
    }
}