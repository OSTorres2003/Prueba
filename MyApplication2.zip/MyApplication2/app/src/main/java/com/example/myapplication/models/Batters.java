package com.example.myapplication.models;

import java.io.Serializable;
import java.util.List;

public class Batters  implements Serializable  {
    private List<Batter> batter;

    public List<Batter> getBatter() {
        return batter;
    }

    public Batters() {
    }

    public Batters(List<Batter> batter) {
        this.batter = batter;
    }

    public void setBatter(List<Batter> batter) {
        this.batter = batter;

    }
}
