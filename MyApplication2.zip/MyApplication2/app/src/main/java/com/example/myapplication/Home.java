package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.example.myapplication.models.Donut;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import service.ApiCliente;
import service.ApiService;

public class Home extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        ApiService apiService = ApiCliente.retrofitt().create(ApiService.class);
        Call<List<Donut>> call = apiService.getDonut();
        call.enqueue(new Callback<List<Donut>>() {
            @Override
            public void onResponse(Call<List<Donut>> call, Response<List<Donut>> response) {
                if (response.isSuccessful()) {
                    List<Donut> donuts = response.body();

                    // Aquí puedes trabajar con la lista de donuts
                    for (Donut donut : donuts) {
                        Log.d("Donut", "ID: " + donut.getId() + ", Name: " + donut.getName());
                    }
                } else {
                    // Manejar el error
                    Log.e("API Error", "Error en la respuesta: " + response.code());
                }
            }

            @Override
            public void onFailure(Call<List<Donut>> call, Throwable t) {
                // Manejar el fallo
                Log.e("API Error", "Error en la solicitud: " + t.getMessage());
            }
        });

        Button btnsalir = findViewById(R.id.btnSalir);
        btnsalir.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View click){
                startActivity(new Intent(Home.this, MainActivity.class));
            }
        });
    }
}